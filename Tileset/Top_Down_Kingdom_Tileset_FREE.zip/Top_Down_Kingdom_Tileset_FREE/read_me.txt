Hi! Thanks for downloading the Kingdom Tileset asset pack. Made by: SWoolfeek

This asset pack is my first pack, so let me know if there's any specific sprites/themes you'd like in future packs.

License - Free Basic Pack
  - You can modify the assets.
  - You can not redistribute or resale, even if modified.
  - You can only use these assets in non-commercial projects. 
( If you want to make something commercial with these sprites contact me)
  - Attribution is not required but appreciated.

If you enjoy this then leave a rating and comment. It helps to support this project!
